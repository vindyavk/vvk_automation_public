# Copyright (c) 2017 Infoblox Inc.
package Infoblox::Grid::Member::ParentalControl;

use strict;
use Carp;

use Infoblox::Util;
use Infoblox::IBAPBase;
use Infoblox::IBAPTypes;
use Infoblox::PAPIOverrides;

use vars qw(
            $_object_type
            %_allowed_members
            %_capabilities
            %_ibap_to_object
            %_name_mappings
            %_object_to_ibap
            %_return_field_overrides
            %_reverse_name_mappings
            %_searchable_fields
            @ISA
            @_return_fields
);

@ISA = qw( Infoblox::IBAPBase Infoblox::PAPIOverrides::ADD_REMOVE );

BEGIN {

    $_object_type = 'MemberIMC';
    register_wsdl_type('ib:MemberIMC', 'Infoblox::Grid::Member::ParentalControl');

    %_capabilities = (
                      'depth'                => 0,
                      'implicit_defaults'    => 1,
                      'single_serialization' => 1,
    );

    %_allowed_members = (
                         'enable_service' => {simple => 'bool', validator => \&ibap_value_o2i_boolean},
                         'name'           => {readonly => 1},
    );

    Infoblox::IBAPBase::create_accessors(\%_allowed_members);

    %_searchable_fields = (
                           'name' => [\&ibap_o2i_member_name, 'parent', 'EXACT'],
    );

    %_name_mappings = (
                       'name' => 'parent',
    );

    %_reverse_name_mappings = reverse %_name_mappings;

    %_ibap_to_object = (
                        'parent' => \&ibap_i2o_member_name,
    );

    %_object_to_ibap = (
                        'enable_service' => \&ibap_o2i_boolean,
                        'name'           => \&ibap_o2i_ignore,
    );

    @_return_fields = (
                       tField('enable_service'),
                       tField('parent', {sub_fields => [tField('host_name')]}),
    );

    %_return_field_overrides = (
                                'enable_service' => [],
                                'name'           => [],
    );
}

sub __new__ {

    my ($proto, %args) = @_;
    my $class = ref($proto) || $proto;
    my $self = Infoblox::IBAPBase->__new__(%args);

    bless $self, $class;
    return $self;
}

sub new {

    my ($proto, %args) = @_;
    my $class = ref($proto) || $proto;
    my $self = Infoblox::IBAPBase->new(%args);

    bless $self, $class;

    if (!$self->__initialize_members_from_arg_list__(\%_allowed_members, \%args) ||
        !$self->__validate_object_required_members__(\%_allowed_members))
    {
        return;
    }

    return $self;
}

sub __ibap_object_type__ {

    return $_object_type;
}

sub __ibap_capabilities__ {

    my ($self, $what) = @_;
    return $_capabilities{$what};
}

sub __ibap_to_object__ {

    my ($self, $ibap_object_ref, $server, $session, $return_object_cache_ref) = @_;

    $$ibap_object_ref{'enable_service'} = 0 unless defined $$ibap_object_ref{'enable_service'};

    return $self->SUPER::__ibap_to_object__($ibap_object_ref, $server, $session, $return_object_cache_ref);
}


package Infoblox::Grid::ParentalControl::SiteMember;

use strict;
use Carp;

use Infoblox::Util;
use Infoblox::IBAPBase;
use Infoblox::IBAPTypes;
use Infoblox::PAPIOverrides;

use vars qw(
            $_object_type
            %_allowed_members
            %_name_mappings
            %_object_to_ibap
            %_ibap_to_object
            %_reverse_name_mappings
            @ISA
            @_return_fields
);

@ISA = qw( Infoblox::IBAPBase Infoblox::PAPIOverrides::ALL );

BEGIN {

    $_object_type = 'imc_site_member';
    register_wsdl_type('ib:imc_site_member', 'Infoblox::Grid::ParentalControl::SiteMember');

    %_allowed_members = (
                         'name' => {mandatory => 1, validator => \&ibap_value_o2i_string},
                         'type' => {simple => 'asis', enum => ['BOTH', 'CLIENT', 'COLLECTOR', 'NONE']},
    );

    Infoblox::IBAPBase::create_accessors(\%_allowed_members);

    %_name_mappings = (
                       'name' => 'member',
    );

    %_reverse_name_mappings = reverse %_name_mappings;

    %_object_to_ibap = (
                        'name' => \&ibap_o2i_member_name,
                        'type' => \&ibap_o2i_string,
    );

    %_ibap_to_object = (
                        'member' => \&ibap_i2o_member_name,
    );

    @_return_fields = (
                       tField('type'),
                       tField('member', {sub_fields => [tField('host_name')]}),
    );
}

sub __new__ {

    my ($proto, %args) = @_;
    my $class = ref($proto) || $proto;
    my $self = Infoblox::IBAPBase->__new__(%args);

    bless $self, $class;
    return $self;
}

sub new {

    my ($proto, %args) = @_;
    my $class = ref($proto) || $proto;
    my $self = Infoblox::IBAPBase->new(%args);

    bless $self, $class;

    if (!$self->__initialize_members_from_arg_list__(\%_allowed_members, \%args) ||
        !$self->__validate_object_required_members__(\%_allowed_members))
    {
        return;
    }

    return $self;
}

sub __ibap_object_type__ {

    return $_object_type;
}


package Infoblox::Grid::ParentalControl::NAS::Gateway;

use strict;
use Carp;

use Infoblox::Util;
use Infoblox::IBAPBase;
use Infoblox::IBAPTypes;
use Infoblox::PAPIOverrides;

use vars qw(
            $_object_type
            %_allowed_members
            %_name_mappings
            %_object_to_ibap
            %_reverse_name_mappings
            @ISA
            @_return_fields
);

@ISA = qw( Infoblox::IBAPBase Infoblox::PAPIOverrides::ALL );

BEGIN {

    $_object_type = 'imc_accounting_log_server';
    register_wsdl_type('ib:imc_accounting_log_server', 'Infoblox::Grid::ParentalControl::NAS::Gateway');

    %_allowed_members = (
                         'address'       => {mandatory => 1, simple => 'asis', validator => \&ibap_value_o2i_ipv4addr},
                         'comment'       => {simple => 'asis', validator => \&ibap_value_o2i_string},
                         'message_rate'  => {simple => 'asis', readonly => 1},
                         'name'          => {mandatory => 1, simple => 'asis', validator => \&ibap_value_o2i_string},
                         'send_ack'      => {simple => 'bool', validator => \&ibap_value_o2i_boolean},
                         'shared_secret' => {writeonly => 1, validator => \&ibap_value_o2i_string},
    );

    Infoblox::IBAPBase::create_accessors(\%_allowed_members);

    %_name_mappings = (
                       'address' => 'ip_address',
    );

    %_reverse_name_mappings = reverse %_name_mappings;

    %_object_to_ibap = (
                        'address'       => \&ibap_o2i_string,
                        'comment'       => \&ibap_o2i_string,
                        'message_rate'  => \&ibap_o2i_ignore,
                        'name'          => \&ibap_o2i_string,
                        'send_ack'      => \&ibap_o2i_boolean,
                        'shared_secret' => \&ibap_o2i_string_skip_undef,
    );

    @_return_fields = (
                       tField('comment'),
                       tField('ip_address'),
                       tField('message_rate'),
                       tField('name'),
                       tField('send_ack'),
    );
}

sub __new__ {

    my ($proto, %args) = @_;
    my $class = ref($proto) || $proto;
    my $self = Infoblox::IBAPBase->__new__(%args);

    bless $self, $class;
    return $self;
}

sub new {

    my ($proto, %args) = @_;
    my $class = ref($proto) || $proto;
    my $self = Infoblox::IBAPBase->new(%args);

    bless $self, $class;

    if (!$self->__initialize_members_from_arg_list__(\%_allowed_members, \%args) ||
        !$self->__validate_object_required_members__(\%_allowed_members))
    {
        return;
    }

    return $self;
}

sub __ibap_object_type__ {

    return $_object_type;
}

sub __ibap_to_object__ {

    my ($self, $ibap_object_ref, $server, $session, $return_object_cache_ref) = @_;

    $$ibap_object_ref{'send_ack'} = 0 unless defined $$ibap_object_ref{'send_ack'};

    return $self->SUPER::__ibap_to_object__($ibap_object_ref, $server, $session, $return_object_cache_ref);
}


package Infoblox::Grid::ParentalControl::NAS::AVP;

use strict;
use Carp;

use Infoblox::Util;
use Infoblox::IBAPBase;
use Infoblox::IBAPTypes;


use vars qw(
            $_object_type
            %_allowed_members
            %_capabilities
            %_object_to_ibap
            %_return_field_overrides
            %_searchable_fields
            @ISA
            @_value_type_enum
            @_domain_types_enum
            @_return_fields
);

@ISA = qw( Infoblox::IBAPBase );

BEGIN {

    $_object_type = 'IMCAccountingAvp';
    register_wsdl_type('ib:IMCAccountingAvp', 'Infoblox::Grid::ParentalControl::NAS::AVP');

    %_capabilities = (
                      'depth'                => 0,
                      'implicit_defaults'    => 1,
                      'single_serialization' => 1,
    );

    @_value_type_enum = (
        'BYTE',
        'DATE',
        'INTEGER',
        'INTEGER64',
        'IPADDR',
        'IPV6ADDR',
        'IPV6IFID',
        'IPV6PREFIX',
        'OCTETS',
        'SHORT',
        'STRING',
    );

    @_domain_types_enum = (
        'SUBS_ID',
        'ANCILLARY',
        'NAS_CONTEXT',
        'IP_SPACE_DIS',
    );

    %_allowed_members = (
                         'comment'       => {simple => 'asis', validator => \&ibap_value_o2i_string},
                         'domain_types'  => {array => 1, simple => 'asis', enum => \@_domain_types_enum},
                         'is_restricted' => {simple => 'bool', validator => \&ibap_value_o2i_boolean},
                         'name'          => {mandatory => 1, simple => 'asis', validator => \&ibap_value_o2i_string},
                         'type'          => {mandatory => 1, simple => 'asis', validator => \&ibap_value_o2i_uint},
                         'user_defined'  => {simple => 'bool', readonly => 1},
                         'value_type'    => {mandatory => 1, simple => 'asis', enum => \@_value_type_enum},
                         'vendor_id'     => {simple => 'asis', validator => \&ibap_value_o2i_uint},
                         'vendor_type'   => {simple => 'asis', validator => \&ibap_value_o2i_uint},
    );

    Infoblox::IBAPBase::create_accessors(\%_allowed_members);

    %_searchable_fields = (
                           'comment'     => [\&ibap_o2i_string, 'comment', 'REGEX'],
                           'name'        => [\&ibap_o2i_string, 'name', 'REGEX'],
                           'type'        => [\&ibap_o2i_uint, 'type', 'EXACT'],
                           'vendor_id'   => [\&ibap_o2i_uint, 'vendor_id', 'EXACT'],
                           'vendor_type' => [\&ibap_o2i_uint, 'vendor_type', 'EXACT'],
    );

    %_object_to_ibap = (
                        'comment'       => \&ibap_o2i_string,
                        'domain_types'  => \&ibap_o2i_string_array_undef_to_empty,
                        'is_restricted' => \&ibap_o2i_boolean,
                        'name'          => \&ibap_o2i_string,
                        'type'          => \&ibap_o2i_uint,
                        'user_defined'  => \&ibap_o2i_ignore,
                        'value_type'    => \&ibap_o2i_string,
                        'vendor_id'     => \&ibap_o2i_uint,
                        'vendor_type'   => \&ibap_o2i_uint,
    );

    @_return_fields = (
                       tField('comment'),
                       tField('domain_types'),
                       tField('is_restricted'),
                       tField('name'),
                       tField('type'),
                       tField('user_defined'),
                       tField('value_type'),
                       tField('vendor_id'),
                       tField('vendor_type'),
    );

    %_return_field_overrides = (
                                'comment'       => [],
                                'is_restricted' => [],
                                'name'          => [],
                                'type'          => [],
                                'user_defined'  => [],
                                'value_type'    => [],
                                'vendor_id'     => [],
                                'vendor_type'   => [],
    );
}

sub __new__ {

    my ($proto, %args) = @_;
    my $class = ref($proto) || $proto;
    my $self = Infoblox::IBAPBase->__new__(%args);

    bless $self, $class;
    return $self;
}

sub new {

    my ($proto, %args) = @_;
    my $class = ref($proto) || $proto;
    my $self = Infoblox::IBAPBase->new(%args);

    bless $self, $class;

    if (!$self->__initialize_members_from_arg_list__(\%_allowed_members, \%args) ||
        !$self->__validate_object_required_members__(\%_allowed_members))
    {
        return;
    }

    return $self;
}

sub __ibap_object_type__ {

    return $_object_type;
}

sub __ibap_capabilities__ {

    my ($self, $what) = @_;
    return $_capabilities{$what};
}

sub __ibap_to_object__ {

    my ($self, $ibap_object_ref, $server, $session, $return_object_cache_ref) = @_;

    foreach (
        'is_restricted',
        'user_defined',
    ) {
        $$ibap_object_ref{$_} = 0 unless defined $$ibap_object_ref{$_};
    }

    $$self{domain_types} = [];

    return $self->SUPER::__ibap_to_object__($ibap_object_ref, $server, $session, $return_object_cache_ref);
}


package Infoblox::Grid::ParentalControl::Subscriber;

use strict;
use Carp;

use Infoblox::Util;
use Infoblox::IBAPBase;
use Infoblox::IBAPTypes;
use Infoblox::PAPIOverrides;

use vars qw(
            $_object_type
            $_return_fields_initialized
            %_allowed_members
            %_capabilities
            %_ibap_to_object
            %_name_mappings
            %_object_to_ibap
            %_return_field_overrides
            %_reverse_name_mappings
            @ISA
            @_return_fields
);

@ISA = qw( Infoblox::IBAPBase Infoblox::PAPIOverrides::GET_MODIFY_ONLY );

BEGIN {

    $_object_type = 'IMCSubscriberSecureProperties';
    register_wsdl_type('ib:IMCSubscriberSecureProperties', 'Infoblox::Grid::ParentalControl::Subscriber');

    %_capabilities = (
                      'depth'                => 0,
                      'implicit_defaults'    => 1,
                      'single_serialization' => 1,
    );

    %_allowed_members = (
                         'ancillaries'                          => {array => 1, validator => \&ibap_value_o2i_string},
                         'interim_accounting_interval'          => {simple => 'asis', validator => \&ibap_value_o2i_uint},
                         'ip_anchors'                           => {array => 1, validator => \&ibap_value_o2i_string},
                         'ip_space_discriminator'               => {validator => \&ibap_value_o2i_string},
                         'ip_space_discriminator_regexp'        => {simple => 'asis', validator => \&ibap_value_o2i_string},
                         'ip_space_discriminator_subexpression' => {simple => 'asis', validator => \&ibap_value_o2i_uint},
                         'nas_context_info'                     => {validator => \&ibap_value_o2i_string},
                         'subscriber_id'                        => {validator => \&ibap_value_o2i_string},
                         'subscriber_id_regexp'                 => {simple => 'asis', validator => \&ibap_value_o2i_string},
                         'subscriber_id_subexpression'          => {simple => 'asis', validator => \&ibap_value_o2i_uint},
                         'subscriber_id_subexpression'          => {simple => 'asis', validator => \&ibap_value_o2i_uint},
                         'enable_parental_control'              => {simple => 'bool', validator => \&ibap_value_o2i_boolean},
                         'enable_mgmt_only_nas'                 => {simple => 'bool', validator => \&ibap_value_o2i_boolean},
    );

    Infoblox::IBAPBase::create_accessors(\%_allowed_members);

    %_name_mappings = (
                       'ancillaries'                          => 'ancillary_list',
                       'ip_anchors'                           => 'ip_anchor_list',
                       'ip_space_discriminator'               => 'ip_space_disc',
                       'ip_space_discriminator_regexp'        => 'ip_space_disc_regexp',
                       'ip_space_discriminator_subexpression' => 'ip_space_disc_subexpression',
                       'enable_parental_control'              => 'use_parental_control_enabled',
                       'enable_mgmt_only_nas'                 => 'mgmt_only_nas',
    );

    %_reverse_name_mappings = reverse %_name_mappings;

    %_ibap_to_object = (
                        'ancillary_list'                => \&ibap_i2o_object_list_names,
                        'ip_anchor_list'                => \&ibap_i2o_object_list_names,
                        'ip_space_disc'                 => \&ibap_i2o_object_name,
                        'nas_context_info'              => \&ibap_i2o_object_name,
                        'subscriber_id'                 => \&ibap_i2o_object_name,
    );

    %_object_to_ibap = (
                        'ancillaries'                          => \&__o2i_avp__,
                        'interim_accounting_interval'          => \&ibap_o2i_uint,
                        'ip_anchors'                           => \&__o2i_avp__,
                        'ip_space_discriminator'               => \&__o2i_avp__,
                        'ip_space_discriminator_regexp'        => \&ibap_o2i_string,
                        'ip_space_discriminator_subexpression' => \&ibap_o2i_uint,
                        'nas_context_info'                     => \&__o2i_avp__,
                        'subscriber_id'                        => \&__o2i_avp__,
                        'subscriber_id_regexp'                 => \&ibap_o2i_string,
                        'subscriber_id_subexpression'          => \&ibap_o2i_uint,
                        'enable_parental_control'              => \&ibap_o2i_boolean,
                        'enable_mgmt_only_nas'                 => \&ibap_o2i_boolean,
    );

    @_return_fields = (
                       tField('ancillary_list', {sub_fields => [tField('name')]}),
                       tField('interim_accounting_interval'),
                       tField('ip_anchor_list', {sub_fields => [tField('name')]}),
                       tField('nas_context_info', {sub_fields => [tField('name')]}),
                       tField('subscriber_id', {sub_fields => [tField('name')]}),
                       tField('ip_space_disc', {sub_fields => [tField('name')]}),
                       tField('ip_space_disc_regexp'),
                       tField('ip_space_disc_subexpression'),
                       tField('subscriber_id', {sub_fields => [tField('name')]}),
                       tField('subscriber_id_regexp'),
                       tField('subscriber_id_subexpression'),
                       tField('use_parental_control_enabled'),
                       tField('mgmt_only_nas'),
    );

    %_return_field_overrides = (
                                'ancillaries'                          => [],
                                'interim_accounting_interval'          => [],
                                'ip_anchors'                           => [],
                                'ip_space_discriminator'               => [],
                                'ip_space_discriminator_regexp'        => [],
                                'ip_space_discriminator_subexpression' => [],
                                'nas_context_info'                     => [],
                                'subscriber_id'                        => [],
                                'subscriber_id_regexp'                 => [],
                                'subscriber_id_subexpression'          => [],
                                'subscriber_id_subexpression'          => [],
                                'enable_parental_control'              => [],
                                'enable_mgmt_only_nas'                 => [],
    );

    $_return_fields_initialized = 0;
}

sub __new__ {

    my ($proto, %args) = @_;
    my $class = ref($proto) || $proto;
    my $self = Infoblox::IBAPBase->__new__(%args);

    bless $self, $class;
    return $self;
}

sub new {

    my ($proto, %args) = @_;
    my $class = ref($proto) || $proto;
    my $self = Infoblox::IBAPBase->new(%args);

    bless $self, $class;

    if (!$self->__initialize_members_from_arg_list__(\%_allowed_members, \%args) ||
        !$self->__validate_object_required_members__(\%_allowed_members))
    {
        return;
    }

    return $self;
}

sub __ibap_object_type__ {

    return $_object_type;
}

sub __ibap_capabilities__ {

    my ($self, $what) = @_;
    return $_capabilities{$what};
}

sub __ibap_to_object__ {

    my ($self, $ibap_object_ref, $server, $session, $return_object_cache_ref) = @_;

    foreach (
        'mgmt_only_nas',
        'use_parental_control_enabled',
    ) {
        $$ibap_object_ref{$_} = 0 unless defined $$ibap_object_ref{$_};
    }


    foreach (
        'ancillaries',
        'ip_anchors',
    ) {
        $$self{$_} = [];
    }

    return $self->SUPER::__ibap_to_object__($ibap_object_ref, $server, $session, $return_object_cache_ref);
}

sub __o2i_avp__ {

    my ($self, $session, $current, $tempref) = @_;

    if (ref $$tempref{$current} eq 'ARRAY') {
        my @res;
        foreach my $avp (@{$$tempref{$current}}) {

            my $val = ibap_readfield_simple_string(
                'IMCAccountingAvp', 'name', $avp, $current);

            return (0) unless $val;

            push @res, $val;
        }

        return (1, 0, tIBType('ArrayOfBaseObject', \@res));

    } else {

        return (1, 0, undef) unless $$tempref{$current};

        my $val = ibap_readfield_simple_string(
            'IMCAccountingAvp', 'name', $$tempref{$current}, $current);

        return (defined $val ? (1, 0, $val) : (0));
    }
}


package Infoblox::Grid::ParentalControl::SubscriberSite;

use strict;
use Carp;

use Infoblox::Util;
use Infoblox::IBAPBase;
use Infoblox::IBAPTypes;


use vars qw(
            $_object_type
            $_return_fields_initialized
            %_allowed_members
            %_capabilities
            %_ibap_to_object
            %_name_mappings
            %_object_to_ibap
            %_return_field_overrides
            %_reverse_name_mappings
            %_searchable_fields
            @ISA
            @_return_fields
);

@ISA = qw( Infoblox::IBAPBase );

BEGIN {

    $_object_type = 'IMCSubscriberSecureSite';
    register_wsdl_type('ib:IMCSubscriberSecureSite', 'Infoblox::Grid::ParentalControl::SubscriberSite');

    %_capabilities = (
                      'depth'                => 0,
                      'implicit_defaults'    => 1,
                      'single_serialization' => 1,
    );

    %_allowed_members = (
                         'comment'               => {simple => 'asis', validator => \&ibap_value_o2i_string},
                         'maximum_subscribers'   => {mandatory => 1, simple => 'asis', validator => \&ibap_value_o2i_uint},
                         'members'               => {array => 1, validator => {'Infoblox::Grid::ParentalControl::SiteMember' => 1}},
                         'name'                  => {mandatory => 1, simple => 'asis', validator => \&ibap_value_o2i_string},
                         'nas_gateways'          => {array => 1, validator => {'Infoblox::Grid::ParentalControl::NAS::Gateway' => 1}},
                         'nas_port'              => {mandatory => 1, simple => 'asis', validator => \&ibap_value_o2i_uint},
                         'blocking_ipv4_vip1'    => {simple => 'asis', validator => \&ibap_value_o2i_ipv4addr},
                         'blocking_ipv6_vip1'    => {simple => 'asis', validator => \&ibap_value_o2i_ipv6addr},
                         'blocking_ipv4_vip2'    => {simple => 'asis', validator => \&ibap_value_o2i_ipv4addr},
                         'blocking_ipv6_vip2'    => {simple => 'asis', validator => \&ibap_value_o2i_ipv6addr},
                         'msps'                  => {array => 1, validator => {'Infoblox::Grid::ParentalControl::MSP' => 1}},
                         'extattrs'              => {special => 'extensible_attributes'},
                         'extensible_attributes' => {special => 'extensible_attributes'},
    );

    Infoblox::IBAPBase::create_accessors(\%_allowed_members);

    %_searchable_fields = (
                           'name'                  => [\&ibap_o2i_string, 'name', 'REGEX', 'IGNORE_CASE'],
                           'comment'               => [\&ibap_o2i_string, 'comment', 'REGEX', 'IGNORE_CASE'],
                           'blocking_ipv4_vip1'    => [\&ibap_o2i_string, 'blocking_ipv4_vip1', 'REGEX', 'IGNORE_CASE'],
                           'blocking_ipv6_vip1'    => [\&ibap_o2i_string, 'blocking_ipv6_vip1', 'REGEX', 'IGNORE_CASE'],
                           'blocking_ipv4_vip2'    => [\&ibap_o2i_string, 'blocking_ipv4_vip2', 'REGEX', 'IGNORE_CASE'],
                           'blocking_ipv6_vip2'    => [\&ibap_o2i_string, 'blocking_ipv6_vip2', 'REGEX', 'IGNORE_CASE'],
                           'extattrs'              => [\&Infoblox::IBAPBase::__o2i_search_extensible_attributes__, 'extensible_attributes', 'SUBSET'],
                           'extensible_attributes' => [\&Infoblox::IBAPBase::__o2i_search_extensible_attributes__, 'extensible_attributes', 'SUBSET'],
    );

    %_name_mappings = (
                       'members'  => 'member_list',
                       'msps'     => 'msp_list',
                       'extattrs' => 'extensible_attributes',
    );

    %_reverse_name_mappings = reverse %_name_mappings;

    %_ibap_to_object = (
                        'member_list'           => \&ibap_i2o_generic_object_list_convert,
                        'nas_gateways'          => \&ibap_i2o_generic_object_list_convert,
                        'msp_list'              => \&ibap_i2o_generic_object_list_convert,
                        'extensible_attributes' => \&Infoblox::IBAPBase::__i2o_extensible_attributes__,
    );

    %_object_to_ibap = (
                        'comment'               => \&ibap_o2i_string,
                        'maximum_subscribers'   => \&ibap_o2i_uint,
                        'members'               => \&ibap_o2i_generic_struct_list_convert,
                        'name'                  => \&ibap_o2i_string,
                        'nas_gateways'          => \&ibap_o2i_generic_struct_list_convert,
                        'nas_port'              => \&ibap_o2i_uint,
                        'blocking_ipv4_vip1'    => \&ibap_o2i_string_undef_to_empty,
                        'blocking_ipv6_vip1'    => \&ibap_o2i_string_undef_to_empty,
                        'blocking_ipv4_vip2'    => \&ibap_o2i_string_undef_to_empty,
                        'blocking_ipv6_vip2'    => \&ibap_o2i_string_undef_to_empty,
                        'msps'                  => \&ibap_o2i_generic_struct_list_convert,
                        'extattrs'              => \&Infoblox::IBAPBase::__o2i_extensible_attributes__,
                        'extensible_attributes' => \&ibap_o2i_ignore,
    );

    @_return_fields = (
                       tField('comment'),
                       tField('maximum_subscribers'),
                       tField('name'),
                       tField('nas_port'),
                       tField('blocking_ipv4_vip1'),
                       tField('blocking_ipv6_vip1'),
                       tField('blocking_ipv4_vip2'),
                       tField('blocking_ipv6_vip2'),
                       return_fields_extensible_attributes(),
    );

    %_return_field_overrides = (
                                'comment'               => [],
                                'maximum_subscribers'   => [],
                                'members'               => [],
                                'name'                  => [],
                                'nas_gateways'          => [],
                                'nas_port'              => [],
                                'blocking_ipv4_vip1'    => [],
                                'blocking_ipv6_vip1'    => [],
                                'blocking_ipv4_vip2'    => [],
                                'blocking_ipv6_vip2'    => [],
                                'msps'                  => [],
                                'extattrs'              => [],
                                'extensible_attributes' => [],
    );

    $_return_fields_initialized = 0;
}

sub __new__ {

    my ($proto, %args) = @_;
    my $class = ref($proto) || $proto;
    my $self = Infoblox::IBAPBase->__new__(%args);

    bless $self, $class;

    $self->__init_instance_constants__();
    return $self;
}

sub new {

    my ($proto, %args) = @_;
    my $class = ref($proto) || $proto;
    my $self = Infoblox::IBAPBase->new(%args);

    bless $self, $class;

    if (!$self->__initialize_members_from_arg_list__(\%_allowed_members, \%args) ||
        !$self->__validate_object_required_members__(\%_allowed_members))
    {
        return;
    }

    $self->__init_instance_constants__();
    return $self;
}

sub __ibap_object_type__ {

    return $_object_type;
}

sub __ibap_capabilities__ {

    my ($self, $what) = @_;
    return $_capabilities{$what};
}

sub __ibap_to_object__ {

    my ($self, $ibap_object_ref, $server, $session, $return_object_cache_ref) = @_;

    foreach (
        'members',
        'nas_gateways',
        'msps',
    ) {
        $$self{$_} = [];
    }

    return $self->SUPER::__ibap_to_object__($ibap_object_ref, $server, $session, $return_object_cache_ref);
}

sub __init_instance_constants__ {

    my $self = shift;

    unless ($_return_fields_initialized) {

        $_return_fields_initialized = 1;

        my ($tmp, %tmp);

        %tmp = (
                'nas_gateways' => 'Infoblox::Grid::ParentalControl::NAS::Gateway',
                'member_list'  => 'Infoblox::Grid::ParentalControl::SiteMember',
                'msp_list'     => 'Infoblox::Grid::ParentalControl::MSP',
        );

        foreach my $key (keys %tmp) {
            $tmp = $tmp{$key}->__new__();
            push @_return_fields, tField($key, {sub_fields => $tmp->__return_fields__()});
        }
    }
}


package Infoblox::Grid::ParentalControl::MSP;

use strict;
use Carp;

use Infoblox::Util;
use Infoblox::IBAPBase;
use Infoblox::IBAPTypes;
use Infoblox::PAPIOverrides;

use vars qw(
            $_object_type
            %_allowed_members
            %_ibap_to_object
            %_name_mappings
            %_object_to_ibap
            %_reverse_name_mappings
            @ISA
            @_return_fields
);

@ISA = qw( Infoblox::IBAPBase Infoblox::PAPIOverrides::ALL );

BEGIN {

    $_object_type = 'imc_site_msp';
    register_wsdl_type('ib:imc_site_msp', 'Infoblox::Grid::ParentalControl::MSP');


    %_allowed_members = (
                         'address' => {mandatory => 1, simple => 'asis', validator => \&ibap_value_o2i_ipv4addr},
    );

    Infoblox::IBAPBase::create_accessors(\%_allowed_members);

    %_name_mappings = (
                       'address' => 'ip_address',
    );

    %_reverse_name_mappings = reverse %_name_mappings;

    %_ibap_to_object = (
    );

    %_object_to_ibap = (
                        'address' => \&ibap_o2i_string,
    );

    @_return_fields = (
                       tField('ip_address'),
    );
}

sub __new__ {

    my ($proto, %args) = @_;
    my $class = ref($proto) || $proto;
    my $self = Infoblox::IBAPBase->__new__(%args);

    bless $self, $class;
    return $self;
}

sub new {

    my ($proto, %args) = @_;
    my $class = ref($proto) || $proto;
    my $self = Infoblox::IBAPBase->new(%args);

    bless $self, $class;

    if (!$self->__initialize_members_from_arg_list__(\%_allowed_members, \%args) ||
        !$self->__validate_object_required_members__(\%_allowed_members))
    {
        return;
    }

    return $self;
}

sub __ibap_object_type__ {

    return $_object_type;
}


1;
